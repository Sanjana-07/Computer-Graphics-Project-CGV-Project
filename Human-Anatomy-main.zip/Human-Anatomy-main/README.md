# Human-Anatomy
Computer Graphics mini project using c++ . 
